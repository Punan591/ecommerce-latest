<footer class="main-footer">
    <strong>Copyright &copy; 2019-2021 <a href="#">SE Project 2021</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.2
    </div>
  </footer>