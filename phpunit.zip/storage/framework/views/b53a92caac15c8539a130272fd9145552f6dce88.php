<?php $__env->startSection('content'); ?>
<div class="span9">
	<ul class="breadcrumb">
		<li><a href="index.html">Home</a> <span class="divider">/</span></li>
		<li class="active"> Shopping Cart</li>
	</ul>
	<h3>  SHOPPING CART [ <small><span class="totalCartItems"><?php echo e(totalCartItems()); ?></span> Item(s) </small>]<a href="<?php echo e(url('/')); ?>" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>
	<hr class="soft"/>
	<?php if(Session::has('success_message')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success_message')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php Session::forget('success_message'); ?>
    <?php endif; ?>
    <?php if(Session::has('error_message')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(Session::get('error_message')); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php Session::forget('error_message'); ?>
    <?php endif; ?>

    <div id="AppendCartItems">
		<?php echo $__env->make('front.products.cart_items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<table class="table table-bordered">
		<tbody>
			<tr>
				<td>
					<form id="ApplyCoupon" method="post" action="javascript:void(0);" class="form-horizontal" <?php if(Auth::check()): ?> user="1" <?php endif; ?>><?php echo csrf_field(); ?>
						<div class="control-group">
							<label class="control-label"><strong> COUPON CODE: </strong> </label>
							<div class="controls">
								<input name="code" id="code" type="text" class="input-medium" placeholder="Enter Coupon Code" required="">
								<button type="submit" class="btn"> APPLY </button>
							</div>
						</div>
					</form>
				</td>
			</tr>
			
		</tbody>
	</table>
	<a href="<?php echo e(url('/')); ?>" class="btn btn-large"><i class="icon-arrow-left"></i> Continue Shopping </a>
	<a href="<?php echo e(url('checkout')); ?>" class="btn btn-large pull-right">Next <i class="icon-arrow-right"></i></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_layout.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Punan\Desktop\LARAVEL PROJECT\ecom150\resources\views/front/products/cart.blade.php ENDPATH**/ ?>