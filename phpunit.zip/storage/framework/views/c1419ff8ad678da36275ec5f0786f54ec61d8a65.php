<?php $__env->startSection('content'); ?>

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Catalogues</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Products</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <?php if($errors->any()): ?>
          <div class="alert alert-danger" style="margin-top: 10px;">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
        <?php endif; ?>
        <?php if(Session::has('success_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 10px;">
              <?php echo e(Session::get('success_message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        <form name="productForm" id="ProductForm" <?php if(empty($productdata['id'])): ?> action="<?php echo e(url('admin/add-edit-product')); ?>" <?php else: ?> action="<?php echo e(url('admin/add-edit-product/'.$productdata['id'])); ?>" <?php endif; ?> method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title"><?php echo e($title); ?></h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
              </div>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Select Category</label>
                    <select name="category_id" id="category_id" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <optgroup label="<?php echo e($section['name']); ?>"></optgroup>
                        <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($category['id']); ?>" <?php if(!empty(@old('category_id')) && $category['id']==@old('category_id')): ?> selected="" <?php elseif(!empty($productdata['category_id']) && $productdata['category_id']==$category['id']): ?> selected="" <?php endif; ?>>&nbsp;&nbsp;&nbsp;--&nbsp;&nbsp;<?php echo e($category['category_name']); ?></option>
                          <?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subcategory['id']); ?>" <?php if(!empty(@old('category_id')) && $subcategory['id']==@old('category_id')): ?> selected="" <?php elseif(!empty($productdata['category_id']) && $productdata['category_id']==$subcategory['id']): ?> selected="" <?php endif; ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--&nbsp;<?php echo e($subcategory['category_name']); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Select Brand</label>
                    <select name="brand_id" id="brand_id" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand['id']); ?>" <?php if(!empty($productdata['brand_id']) && $productdata['brand_id']==$brand['id']): ?> selected="" <?php endif; ?>><?php echo e($brand['name']); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-6"> 
                  <div class="form-group">
                      <label for="product_name">Product Name</label>
                      <input type="text" class="form-control" name="product_name" id="product_name" placeholder="Enter Product Name" <?php if(!empty($productdata['product_name'])): ?> value="<?php echo e($productdata['product_name']); ?>" <?php else: ?> value="<?php echo e(old('product_name')); ?>" <?php endif; ?>>
                  </div>
                  <div class="form-group">
                      <label for="product_code">Product Code</label>
                      <input type="text" class="form-control" name="product_code" id="product_code" placeholder="Enter Product Code" <?php if(!empty($productdata['product_code'])): ?> value="<?php echo e($productdata['product_code']); ?>" <?php else: ?> value="<?php echo e(old('product_code')); ?>" <?php endif; ?>>
                  </div>
                  
                </div> 
                <div class="col-md-6"> 
                  <div class="form-group">
                      <label for="product_color">Product Color</label>
                      <input type="text" class="form-control" name="product_color" id="product_color" placeholder="Enter Product Name" <?php if(!empty($productdata['product_color'])): ?> value="<?php echo e($productdata['product_color']); ?>" <?php else: ?> value="<?php echo e(old('product_color')); ?>" <?php endif; ?>>
                  </div>
                  <div class="form-group">
                      <label for="product_price">Product Price</label>
                      <input type="text" class="form-control" name="product_price" id="product_price" placeholder="Enter Product Price" <?php if(!empty($productdata['product_price'])): ?> value="<?php echo e($productdata['product_price']); ?>" <?php else: ?> value="<?php echo e(old('product_price')); ?>" <?php endif; ?>>
                  </div>
                  <div class="form-group">
                      <label for="product_discount">Product Discount (%)</label>
                      <input type="text" class="form-control" name="product_discount" id="product_discount" placeholder="Enter Product Discount" <?php if(!empty($productdata['product_discount'])): ?> value="<?php echo e($productdata['product_discount']); ?>" <?php else: ?> value="<?php echo e(old('product_discount')); ?>" <?php endif; ?>>
                  </div>
                </div> 
                <div class="col-md-6"> 
                  <div class="form-group">
                      <label for="product_weight">Product Weight</label>
                      <input type="text" class="form-control" name="product_weight" id="product_weight" placeholder="Enter Product Discount" <?php if(!empty($productdata['product_weight'])): ?> value="<?php echo e($productdata['product_weight']); ?>" <?php else: ?> value="<?php echo e(old('product_weight')); ?>" <?php endif; ?>>
                  </div>
                  <div class="form-group">
                      <label for="main_image">Product Main Image</label>
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="main_image" name="main_image">
                          <label class="custom-file-label" for="main_image">Choose file</label>
                        </div>
                        <div class="input-group-append">
                          <span class="input-group-text" id="">Upload</span>
                        </div>
                      </div>
                      <div>Recommended Image Size: Width:1000px, Height:1000px)</div>
                      <?php if(!empty($productdata['main_image'])): ?>
                          <div><img style="width:80px; margin-top: 5px;" src="<?php echo e(asset('images/product_images/small/'.$productdata['main_image'])); ?>">
                          &nbsp;
                          <a class="confirmDelete" href="javascript:void(0)" record="product-image" recordid="<?php echo e($productdata['id']); ?>">Delete Image</a>
                          </div>
                      <?php endif; ?>
                      <div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-12 col-sm-6">
                  <div class="form-group">
                      <label for="product_video">Product Video</label>
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="product_video" name="product_video">
                          <label class="custom-file-label" for="product_video">Choose file</label>
                        </div>
                        <div class="input-group-append">
                          <span class="input-group-text" id="">Upload</span>
                        </div>
                      </div>
                      <?php if(!empty($productdata['product_video'])): ?>
                        <div><a href="<?php echo e(url('videos/product_videos/'.$productdata['product_video'])); ?>" download>Download</a>&nbsp;|&nbsp;
                          <a class="confirmDelete" href="javascript:void(0)" record="product-video" recordid="<?php echo e($productdata['id']); ?>">Delete Video</a></div>
                      <?php endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="description">Product Description</label>
                      <textarea name="description" id="description" class="form-control" rows="3" placeholder="Enter ..."><?php if(!empty($productdata['description'])): ?> <?php echo e($productdata['description']); ?> <?php else: ?> <?php echo e(old('description')); ?> <?php endif; ?></textarea>
                  </div>
                </div>
                <div class="col-12 col-sm-6">
                  <div class="form-group">
                      <label for="wash_care">Wash Care</label>
                      <textarea name="wash_care" id="wash_care" class="form-control" rows="3" placeholder="Enter ..."><?php if(!empty($productdata['wash_care'])): ?> <?php echo e($productdata['wash_care']); ?> <?php else: ?> <?php echo e(old('wash_care')); ?> <?php endif; ?></textarea>
                  </div>
                  <div class="form-group">
                    <label>Select Fabric</label>
                    <select name="fabric" id="fabric" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $fabricArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fabric); ?>" <?php if(!empty($productdata['fabric']) && $productdata['fabric']==$fabric): ?> selected="" <?php endif; ?>><?php echo e($fabric); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-12 col-sm-6">
                  <div class="form-group">
                    <label>Select Sleeve</label>
                    <select name="sleeve" id="sleeve" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $sleeveArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sleeve); ?>" <?php if(!empty($productdata['sleeve']) && $productdata['sleeve']==$sleeve): ?> selected="" <?php endif; ?>><?php echo e($sleeve); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Select Pattern</label>
                    <select name="pattern" id="pattern" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $patternArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pattern); ?>" <?php if(!empty($productdata['pattern']) && $productdata['pattern']==$pattern): ?> selected="" <?php endif; ?>><?php echo e($pattern); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>  
                </div>
                <div class="col-12 col-sm-6">
                  <div class="form-group">
                    <label>Select Fit</label>
                    <select name="fit" id="fit" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $fitArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fit); ?>" <?php if(!empty($productdata['fit']) && $productdata['fit']==$fit): ?> selected="" <?php endif; ?>><?php echo e($fit); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Select Occasion</label>
                    <select name="occasion" id="occasion" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $occasionArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($occasion); ?>" <?php if(!empty($productdata['occasion']) && $productdata['occasion']==$occasion): ?> selected="" <?php endif; ?>><?php echo e($occasion); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-12 col-sm-6">
                  <div class="form-group">
                      <label for="meta_title">Meta Title</label>
                      <textarea id="meta_title" name="meta_title" class="form-control" rows="3" placeholder="Enter ..."><?php if(!empty($productdata['meta_title'])): ?> <?php echo e($productdata['meta_title']); ?> <?php else: ?> <?php echo e(old('meta_title')); ?> <?php endif; ?></textarea>
                  </div>
                </div>
                <div class="col-12 col-sm-6">
                  <div class="form-group">
                      <label for="meta_description">Meta Description</label>
                      <textarea id="meta_description" name="meta_description" class="form-control" rows="3" placeholder="Enter ..."><?php if(!empty($productdata['meta_description'])): ?> <?php echo e($productdata['meta_description']); ?> <?php else: ?> <?php echo e(old('meta_description')); ?> <?php endif; ?></textarea>
                  </div>
                </div>
                <div class="col-12 col-sm-6">
                  <div class="form-group">
                      <label for="meta_keywords">Meta Keywords</label>
                      <textarea name="meta_keywords" id="meta_keywords" class="form-control" rows="3" placeholder="Enter ..."><?php if(!empty($productdata['meta_keywords'])): ?> <?php echo e($productdata['meta_keywords']); ?> <?php else: ?> <?php echo e(old('meta_keywords')); ?> <?php endif; ?></textarea>
                  </div>
                  <div class="form-group">
                      <label for="meta_keywords">Featured Item</label>
                      <input type="checkbox" name="is_featured" id="is_featured" value="Yes" <?php if(!empty($productdata['is_featured']) && $productdata['is_featured']=="Yes"): ?> checked="" <?php endif; ?>>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </div>
        </form>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ecommerce Project\ecom150\ecom150\resources\views/admin/products/add_edit_product.blade.php ENDPATH**/ ?>