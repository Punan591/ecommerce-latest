<?php use App\Product; ?>
<table class="table table-bordered">
	<thead>
		<tr>
			<th>Product</th>
			<th colspan="2">Description</th>
			<th>Quantity/Update</th>
			<th>Price</th>
			<th>Category/Product <br>Discount</th>
			<th>Sub Total</th>
		</tr>
	</thead>
	<tbody>
		<?php $total_price = 0; ?>
		<?php $__currentLoopData = $userCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $attrPrice = Product::getDiscountedAttrPrice($item['product_id'],$item['size']); ?>
		<tr>
			<td> <img width="60" src="<?php echo e(asset('images/product_images/'.$item['product']['main_image'])); ?>" alt=""/></td>
			<td colspan="2">
				<?php echo e($item['product']['product_name']); ?> (<?php echo e($item['product']['product_code']); ?>)<br/>
				Color : <?php echo e($item['product']['product_color']); ?><br/>
				Size : <?php echo e($item['size']); ?><br/>
			</td>
			<td>
				<div class="input-append">
					<input class="span1" style="max-width:34px" value="<?php echo e($item['quantity']); ?>" id="appendedInputButtons" size="16" type="text">
					<button class="btn btnItemUpdate qtyMinus" type="button" data-cartid="<?php echo e($item['id']); ?>"><i class="icon-minus"></i>
					</button>
					<button class="btn btnItemUpdate qtyPlus" type="button" data-cartid="<?php echo e($item['id']); ?>"><i class="icon-plus"></i></button>
					<button class="btn btn-danger btnItemDelete" type="button" data-cartid="<?php echo e($item['id']); ?>"><i class="icon-remove icon-white"></i></button>
				</div>
			</td>
			<td>Rs.<?php echo e($attrPrice['product_price'] * $item['quantity']); ?></td>
			<td>Rs.<?php echo e($attrPrice['discount'] * $item['quantity']); ?></td>
			<td>Rs.<?php echo e($attrPrice['final_price'] * $item['quantity']); ?></td>
		</tr>
		<?php $total_price = $total_price + ($attrPrice['final_price'] * $item['quantity']); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<tr>
			<td colspan="6" style="text-align:right">Sub Total:	</td>
			<td> Rs.<?php echo e($total_price); ?></td>
		</tr>
		<tr>
			<td colspan="6" style="text-align:right">Coupon Discount: </td>
			<td class="couponAmount">
				<?php if(Session::has('couponAmount')): ?>
					- Rs. <?php echo e(Session::get('couponAmount')); ?>

				<?php else: ?>
					Rs. 0
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<td colspan="6" style="text-align:right"><strong>GRAND TOTAL (Rs.<?php echo e($total_price); ?> - <span class="couponAmount">Rs.0</span>) =</strong></td>
			<td class="label label-important" style="display:block"> <strong class="grand_total"> Rs.<?php echo e($total_price - Session::get('couponAmount')); ?> </strong></td>
		</tr>
	</tbody>
</table><?php /**PATH C:\Users\Punan\Desktop\LARAVEL PROJECT\ecom150\resources\views/front/products/cart_items.blade.php ENDPATH**/ ?>