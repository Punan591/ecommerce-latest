<?php use App\Product; ?>

<?php $__env->startSection('content'); ?>
<div class="span9">
	<div class="well well-small" style="background-color:#141414;">
		<h4>Featured Products <small class="pull-right"><?php echo e($featuredItemsCount); ?> featured products</small></h4>
		<div class="row-fluid">
			<div id="featured" <?php if($featuredItemsCount > 4): ?>  class="carousel slide" <?php endif; ?>>
				<div class="carousel-inner">
					<?php $__currentLoopData = $featuredItemsChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $featuredItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item <?php if($key==1): ?> active <?php endif; ?>">
						<ul class="thumbnails">
							<?php $__currentLoopData = $featuredItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="span3">
								<div class="thumbnail" style="background-color:#0f171e; border:none;">
									<i class="tag"></i>
									<a href="<?php echo e(url('product/'.$item['id'])); ?>" style="margin-top:20px;">
										<?php $product_image_path = 'images/product_images/'.$item['main_image']; ?>
										<?php if(!empty($item['main_image']) && file_exists($product_image_path)): ?>
											<img src="<?php echo e(asset($product_image_path)); ?>" alt="">
										<?php else: ?>
											<img src="<?php echo e(asset('images/product_images/no-image.png')); ?>" alt="">
										<?php endif; ?>
									</a>
									<div class="caption" style="color:white;">
										<h5><?php echo e($item['product_name']); ?></h5>
										<?php $discounted_price = Product::getDiscountedPrice($item['id']); ?>
										<h4><a class="btn" href="<?php echo e(url('product/'.$item['id'])); ?>">VIEW</a>
										<span class="pull-right" style="font-size: 15px;">
											<?php if($discounted_price>0): ?>
												<del>Rs.<?php echo e($item['product_price']); ?></del>
												<font color="red">Rs.<?php echo e($discounted_price); ?></font>
											<?php else: ?>
												Rs.<?php echo e($item['product_price']); ?>

											<?php endif; ?>
										</span></h4>
									</div>
								</div>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<!-- <a class="left carousel-control" href="#featured" data-slide="prev">‹</a>
				<a class="right carousel-control" href="#featured" data-slide="next">›</a> -->
			</div>
		</div>
	</div>
	<h4>Latest Products </h4>
	<ul class="thumbnails">
		<?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="span3">
				<div class="thumbnail"  style="background-color:#0f171e; border:none;">
					<a  href="<?php echo e(url('product/'.$product['id'])); ?>" style="margin-top:20px;">
						<?php $product_image_path = 'images/product_images/'.$product['main_image']; ?>
						<?php if(!empty($product['main_image']) && file_exists($product_image_path)): ?>
							<img style="width: 160px;" src="<?php echo e(asset($product_image_path)); ?>" alt="">
						<?php else: ?>
							<img style="width: 160px;" src="<?php echo e(asset('images/product_images/no-image.png')); ?>" alt="">
						<?php endif; ?>
					</a>
					<div class="caption" style="color:white;">
						<h5><?php echo e($product['product_name']); ?></h5>
						<p>
							<?php echo e($product['product_code']); ?> (<?php echo e($product['product_color']); ?>)
						</p>
						<?php $discounted_price = Product::getDiscountedPrice($product['id']); ?>
						<h4 style="text-align:center"><!-- <a class="btn" href="<?php echo e(url('product/'.$product['id'])); ?>"> <i class="icon-zoom-in"></i></a> --> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a>

							<a class="btn btn-primary" href="#">
							<?php if($discounted_price>0): ?>
								<del>Rs.<?php echo e($product['product_price']); ?></del>
								<font color="yellow">Rs.<?php echo e($discounted_price); ?></font>
							<?php else: ?>
								Rs.<?php echo e($product['product_price']); ?>

							<?php endif; ?>
						</a></h4>
					</div>
				</div>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_layout.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Punan\Desktop\LARAVEL PROJECT\ecom150\resources\views/front/index.blade.php ENDPATH**/ ?>