<?php $__env->startSection('content'); ?>
<div class="span9">
	<ul class="breadcrumb" style="background-color:#0f171e;">
		<li><a href="<?php echo e(url('/')); ?>" style="color:white;">Home</a> <span class="divider">/</span></li>
		<li class="active" style="color:white;"><?php echo $categoryDetails['breadcrumbs']; ?></li>
	</ul>
	<h3> <?php echo e($categoryDetails['catDetails']['category_name']); ?> <small class="pull-right"> <?php echo e(count($categoryProducts)); ?> products are available </small></h3>
	<hr class="soft"/>
	<p>
		<?php echo e($categoryDetails['catDetails']['description']); ?>

	</p>
	<hr class="soft"/>
	<form name="sortProducts" id="sortProducts" class="form-horizontal span6">
		<input type="hidden" name="url" id="url" value="<?php echo e($url); ?>">
		<div class="control-group">
			<label class="control-label alignL">Sort By </label>
			<select name="sort" id="sort">
				<option value="">Select</option>
				<option value="product_latest" <?php if(isset($_GET['sort']) && $_GET['sort']=="product_latest"): ?> selected="" <?php endif; ?>>Latest Products</option>
				<option value="product_name_a_z" <?php if(isset($_GET['sort']) && $_GET['sort']=="product_name_a_z"): ?> selected="" <?php endif; ?>>Product name A - Z</option>
				<option value="product_name_z_a" <?php if(isset($_GET['sort']) && $_GET['sort']=="product_name_z_a"): ?> selected="" <?php endif; ?>>Product name Z - A</option>
				<option value="price_lowest" <?php if(isset($_GET['sort']) && $_GET['sort']=="price_lowest"): ?> selected="" <?php endif; ?>>Lowest Price first</option>
				<option value="price_highest" <?php if(isset($_GET['sort']) && $_GET['sort']=="price_highest"): ?> selected="" <?php endif; ?>>Highest Price first</option>
			</select>
		</div>
	</form>
	
	<br class="clr"/>
	<div class="tab-content filter_products">
		<?php echo $__env->make('front.products.ajax_products_listing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<div class="pagination">
		<?php if(isset($_GET['sort']) && !empty($_GET['sort'])): ?>
			<?php echo e($categoryProducts->appends(['sort' => $_GET['sort']])->links()); ?>

		<?php else: ?>
			<?php echo e($categoryProducts->links()); ?>

		<?php endif; ?>
	</div>
	<br class="clr"/>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_layout.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Punan\Desktop\LARAVEL PROJECT\ecom150\resources\views/front/products/listing.blade.php ENDPATH**/ ?>