<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>SE Project 2021</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

	<!-- Front style -->
	<link id="callCss" rel="stylesheet" href="<?php echo e(url('css/front_css/front.min.css')); ?>" media="screen"/>
	<link href="<?php echo e(url('css/front_css/base.css')); ?>" rel="stylesheet" media="screen"/>
	<!-- Front style responsive -->
	<link href="<?php echo e(url('css/front_css/front-responsive.min.css')); ?>" rel="stylesheet"/>
	<link href="<?php echo e(url('css/front_css/font-awesome.css')); ?>" rel="stylesheet" type="text/css">
	<link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
	<!-- Google-code-prettify -->
	<link href="<?php echo e(url('js/front_js/google-code-prettify/prettify.css')); ?>" rel="stylesheet"/>
	<!-- fav and touch icons -->
	<link rel="shortcut icon" href="<?php echo e(asset('images/front_images/ico/favicon.ico')); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('images/front_images/ico/apple-touch-icon-144-precomposed.png')); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('images/front_images/ico/apple-touch-icon-114-precomposed.png')); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('images/front_images/ico/apple-touch-icon-72-precomposed.png')); ?>">
	<link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('images/front_images/ico/apple-touch-icon-57-precomposed.png')); ?>">
	<style type="text/css" id="enject"></style>
	<style>
		form.cmxform label.error, label.error {
		/* remove the next line when you have trouble in IE6 with labels in list */
		color: red;
		font-style: italic
	}
	</style>
</head>
<body style="background-color:#141414; color:white;">
<?php echo $__env->make('layouts.front_layout.front_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header End====================================================================== -->
<?php echo $__env->make('front.banners.home_page_banners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="mainBody" style="background-color:#141414;">
	<div class="container">
		<div class="row">
			<!-- Sidebar ================================================== -->
			<?php echo $__env->make('layouts.front_layout.front_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- Sidebar end=============================================== -->
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</div>
</div>
<!-- Footer ================================================================== -->
<?php echo $__env->make('layouts.front_layout.front_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
<script src="<?php echo e(url('js/front_js/jquery.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('js/front_js/jquery.validate.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('js/front_js/front.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('js/front_js/google-code-prettify/prettify.js')); ?>"></script>

<script src="<?php echo e(url('js/front_js/front.js')); ?>"></script>
<script src="<?php echo e(url('js/front_js/front_script.js')); ?>"></script>
<script src="<?php echo e(url('js/front_js/jquery.lightbox-0.5.js')); ?>"></script>

</body>
</html><?php /**PATH E:\Ecommerce Project\ecom150\ecom150\resources\views/layouts/front_layout/front_layout.blade.php ENDPATH**/ ?>