<?php use App\Product; ?>
<div class="tab-pane  active" id="blockView">
	<ul class="thumbnails">
		<?php $__currentLoopData = $categoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="span3">
				<div class="thumbnail">
					<a href="<?php echo e(url('product/'.$product['id'])); ?>">
						<?php if(isset($product['main_image'])): ?>
							<?php $product_image_path = 'images/product_images/'.$product['main_image']; ?>
						<?php else: ?>
							<?php $product_image_path = ''; ?>
						<?php endif; ?>
						<?php $product_image_path = 'images/product_images/'.$product['main_image']; ?>
						<?php if(!empty($product['main_image']) && file_exists($product_image_path)): ?>
							<img style="width: 250px; height: 250px;" src="<?php echo e(asset($product_image_path)); ?>" alt="">
						<?php else: ?>
							<img style="width: 250px; height: 250px;" src="<?php echo e(asset('images/product_images/no-image.png')); ?>" alt="">
						<?php endif; ?>
					</a>
					<div class="caption">
						<h5><?php echo e($product['product_name']); ?> <?php echo e($product['id']); ?></h5>
						<p>
							<?php echo e($product['brand']['name']); ?>

						</p>
						<?php $discounted_price = Product::getDiscountedPrice($product['id']); ?>
						<h4 style="text-align:center"><!-- <a class="btn" href="<?php echo e(url('product/'.$product['id'])); ?>"> <i class="icon-zoom-in"></i></a> --> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">
						<?php if($discounted_price>0): ?>
							<del>Rs.<?php echo e($product['product_price']); ?></del>
							<font color="yellow">Rs.<?php echo e($discounted_price); ?></font>
						<?php else: ?>
							Rs.<?php echo e($product['product_price']); ?>

						<?php endif; ?>
					</a></h4>
					</div>
				</div>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	<hr class="soft"/>
</div><?php /**PATH C:\Users\Punan\Desktop\LARAVEL PROJECT\ecom150\resources\views/front/products/ajax_products_listing.blade.php ENDPATH**/ ?>