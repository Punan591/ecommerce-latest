<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Catalogues</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Banners</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <!-- /.card -->
          <?php if(Session::has('success_message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 10px;">
                <?php echo e(Session::get('success_message')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Banners</h3>
              <a href="<?php echo e(url('admin/add-edit-banner')); ?>" style="max-width: 150px; float:right; display: inline-block;" class="btn btn-block btn-success">Add Banner</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="banners" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Image</th>
                  <th>Link</th>
                  <th>Title</th>
                  <th>Alt</th>
                  <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($banner['id']); ?></td>
                  <td>
                    <img style="width: 180px;" src="<?php echo e(asset('images/banner_images/'.$banner['image'])); ?>">
                  </td>
                  <td><?php echo e($banner['link']); ?></td>
                  <td><?php echo e($banner['title']); ?></td>
                  <td><?php echo e($banner['alt']); ?></td>
                  <td>
                    <a title="Edit Banner" href="<?php echo e(url('admin/add-edit-banner/'.$banner['id'])); ?>"><i class="fas fa-edit"></i></a>
                    &nbsp;&nbsp;
                    <a title="Delete Banner" href="javascript:void(0)" class="confirmDelete" record="banner" recordid="<?php echo e($banner['id']); ?>"><i class="fas fa-trash"></i></a>
                    &nbsp;&nbsp;
                  	<?php if($banner['status']==1): ?>
                  		<a class="updateBannerStatus" id="banner-<?php echo e($banner['id']); ?>" banner_id="<?php echo e($banner['id']); ?>" href="javascript:void(0)"><i class="fas fa-toggle-on" aria-hidden="true" status="Active"></i></a>
                  	<?php else: ?>
                  		<a class="updateBannerStatus" id="banner-<?php echo e($banner['id']); ?>" banner_id="<?php echo e($banner['id']); ?>" href="javascript:void(0)"><i class="fas fa-toggle-off" aria-hidden="true" status="Inactive"></i></a>
                  	<?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Punan\Desktop\LARAVEL PROJECT\ecom150\resources\views/admin/banners/banners.blade.php ENDPATH**/ ?>