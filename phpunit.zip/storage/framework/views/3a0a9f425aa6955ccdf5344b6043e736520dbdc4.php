<?php
use App\Section;
$sections = Section::sections();
/*echo "<pre>"; print_r($sections); die;*/
?>
<div id="header" >
	<div class="container"> 
		<div id="welcomeLine" class="row">
			<div class="span6">Welcome!<strong> User</strong></div>
			<div class="span6">
				<div class="pull-right">
					<a href="<?php echo e(url('cart')); ?>"><span class="btn btn-mini btn-warning"><i class="icon-shopping-cart icon-white"></i> [ <span class="totalCartItems"><?php echo e(totalCartItems()); ?></span> ] Items in your cart </span> </a>
				</div>
			</div>
		</div>
		<!-- Navbar ================================================== -->
		<section id="navbar" style="background-color:#0f171e!important;">
		  <div class="navbar" style="background-color:#0f171e!important;">
		    <div class="navbar-inner" style="background-color:#0f171e!important; padding-right:0px; padding-left:0px;">
		      <div class="container" style="background-color:#0f171e!important;">
		        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		        </a>
		        <a class="brand" href="#" style="margin-left:-2px;">SE E-Commerce</a>
		        <div class="nav-collapse">
		          <ul class="nav">
		            <li class="active"><a href="#">Home</a></li>
		            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			            <?php if(count($section['categories'])>0): ?>
			            <li class="dropdown">
			              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($section['name']); ?> <b class="caret"></b></a>
			              <ul class="dropdown-menu">
			              	<?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				              	<li class="divider"></li>
				                <li class="nav-header"><a href="<?php echo e(url($category['url'])); ?>"><?php echo e($category['category_name']); ?></a></li>
				                <?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                	<li><a href="<?php echo e(url($subcategory['url'])); ?>"><?php echo e($subcategory['category_name']); ?></a></li>
				                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			              </ul>
			            </li>
			            <?php endif; ?>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		          </ul>
		          <ul class="nav pull-right">
		            <li><a href="<?php echo e(url('orders')); ?>">Orders</a></li>
		            <li class="divider-vertical"></li>
		            <?php if(Auth::check()): ?>
		            	<li><a href="<?php echo e(url('account')); ?>">My Account</a></li>
		            	<li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
		            <?php else: ?>
		            	<li><a href="<?php echo e(url('login-register')); ?>">Login / Register</a></li>
		            <?php endif; ?>
		          </ul>
		        </div><!-- /.nav-collapse -->
		      </div>
		    </div><!-- /navbar-inner -->
		  </div><!-- /navbar -->
		</section>
	</div>
</div><?php /**PATH E:\Ecommerce Project\ecom150\ecom150\resources\views/layouts/front_layout/front_header.blade.php ENDPATH**/ ?>