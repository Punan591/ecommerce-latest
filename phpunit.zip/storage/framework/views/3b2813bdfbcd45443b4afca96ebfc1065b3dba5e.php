<div  id="footerSection" style="margin-top:0px; border-top:1px solid #202020;">
	<div class="container">
		<div class="row">
			<div class="span3">
				<h5>Order</h5>
				<a href="login.html">ORDER HISTORY</a>
			</div>
			<div class="span3">
				<h5>INFORMATION</h5>
				<a href="contact.html">CONTACT</a>
				<a href="tac.html">TERMS AND CONDITIONS</a>
				<a href="faq.html">FAQ</a>
			</div>
			<div class="span3">
				<h5>OUR OFFERS</h5>
				<a href="#">NEW PRODUCTS</a>
				<a href="#">TOP SELLERS</a>
				<a href="#">SPECIAL OFFERS</a>
			</div>
			<div id="socialMedia" class="span3 pull-right">
				<h5>SOCIAL MEDIA </h5>
				<a href="#" style="font-size: 40px" class="twitter"><i class='bx bxl-facebook' ></i></a>
                <a href="#" style="font-size: 40px" class="facebook"><i class='bx bxl-twitter' ></i></a>
                <a href="#" style="font-size: 40px" class="instagram"><i class='bx bxl-instagram' ></i></a>
                <a href="#" style="font-size: 40px" class="linkedin"><i class='bx bxl-telegram' ></i></a>
			</div>
			<p class="text-center"><a target="_blank" href="">&copy; All Rights Reserved | SE E-Commerce</a></p>
		</div>

	</div><!-- Container End -->
</div><?php /**PATH E:\Ecommerce Project\ecom150\ecom150\resources\views/layouts/front_layout/front_footer.blade.php ENDPATH**/ ?>